// problem 3
function Tabb (n,i){
       
    for(var i=1;i<=10;i++){
        console.log(n+"*"+i+"="+n*i+"<br>")
    }
}

var n = prompt("Enter a number:")
Tabb (n,1);